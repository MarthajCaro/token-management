import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Sidebar } from './sidebar';
import { provideAnimations } from '@angular/platform-browser/animations';
import { importProvidersFrom } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { TestComponentRenderer } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

// Mock necesario del renderer
class MockComponentRenderer {
  insertRootElement(rootElementId: string) {
    let root = document.getElementById(rootElementId);
    if (!root) {
      root = document.createElement('div');
      root.id = rootElementId;
      document.body.appendChild(root);
    }
  }
}

describe('Sidebar', () => {
  let component: Sidebar;
  let fixture: ComponentFixture<Sidebar>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        Sidebar,            // standalone component
        HttpClientTestingModule // <-- IMPORTANTE
      ],
      providers: [
        provideAnimations(),
        importProvidersFrom(BrowserModule),
        { provide: TestComponentRenderer, useClass: MockComponentRenderer }
      ]
    }).compileComponents();

    // Crear root manual para Angular 16+
    const root = document.createElement('div');
    root.id = 'root0';
    document.body.appendChild(root);

    TestBed.overrideComponent(Sidebar, {
      set: { template: '' }
    });

    fixture = TestBed.createComponent(Sidebar);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
