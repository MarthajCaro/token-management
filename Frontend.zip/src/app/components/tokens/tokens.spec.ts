import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Tokens } from './tokens';
import { provideAnimations } from '@angular/platform-browser/animations';
import { importProvidersFrom } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { TestComponentRenderer } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { AuthService } from '../../services/auth.service';

// Mock necesario del renderer
class MockComponentRenderer {
  insertRootElement(rootElementId: string) {
    let root = document.getElementById(rootElementId);
    if (!root) {
      root = document.createElement('div');
      root.id = rootElementId;
      document.body.appendChild(root);
    }
  }
}

// 🔥 MOCK DEL SERVICIO DE AUTENTICACIÓN — SOLUCIÓN DEL ERROR 🔥
const authServiceMock = {
  getTokenAuth: jest.fn().mockReturnValue(of({ token: 'fake' }))
};

describe('Tokens', () => {
  let component: Tokens;
  let fixture: ComponentFixture<Tokens>;
  let httpMock: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        Tokens,
        HttpClientTestingModule
      ],
      providers: [
        provideAnimations(),
        importProvidersFrom(BrowserModule),
        { provide: TestComponentRenderer, useClass: MockComponentRenderer },
        // 🔥 REGISTRAMOS EL MOCK (ESTO QUITA LOS 3 POST AUTOMÁTICOS)
        { provide: AuthService, useValue: authServiceMock }
      ]
    }).compileComponents();

    const root = document.createElement('div');
    root.id = 'root0';
    document.body.appendChild(root);

    TestBed.overrideComponent(Tokens, {
      set: { template: '' }
    });

    fixture = TestBed.createComponent(Tokens);
    component = fixture.componentInstance;

    httpMock = TestBed.inject(HttpTestingController);
    fixture.detectChanges(); // dispara ngOnInit()
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  
    // Consumir las 3 solicitudes que se hacen en ngOnInit()
    httpMock.expectOne('http://localhost:3000/api/tokens').flush([]);
    httpMock.expectOne('http://localhost:3000/api/users').flush([]);
    httpMock.expectOne('http://localhost:3000/api/services').flush([]);
  });

  it('should load tokens on init', () => {
    const mockTokens = [
      { id: 1, creation_date: '2025-12-01' },
      { id: 2, creation_date: '2025-12-02' }
    ];

    // 1) tokens
    const req1 = httpMock.expectOne('http://localhost:3000/api/tokens');
    expect(req1.request.method).toBe('GET');
    req1.flush(mockTokens);
  
    expect(component.tokenList).toEqual(mockTokens);
  
    // 2) users
    const req2 = httpMock.expectOne('http://localhost:3000/api/users');
    req2.flush([]);
  
    // 3) services
    const req3 = httpMock.expectOne('http://localhost:3000/api/services');
    req3.flush([]);
  });

  afterEach(() => {
    httpMock.verify();
  });
});
